// This is the Demo API key from https://github.com/giphy/GiphyAPI and not meant to be used
// for production traffic.
module.exports = 'dc6zaTOxFJmzC';
